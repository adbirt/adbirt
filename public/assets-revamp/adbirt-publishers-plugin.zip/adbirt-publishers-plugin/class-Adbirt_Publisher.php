<?php

/**
 * @package adbirt-ads-display
 * @version 1.2.0
 */

// require the widget class before anything else
$widget_file_path = trailingslashit(plugin_dir_path(__FILE__)) . 'includes/class-AAD_widget.php';
require $widget_file_path;

/**
 * The main class for handling the
 * creation and insertion of adbirt ads.
 */
class Adbirt_Publisher
{
    public function __construct()
    {
        add_action('rest_api_init', array($this, 'register_custom_REST_routes'));
        add_action('widgets_init', array($this, 'load_widget'));
        add_action('admin_menu', array($this, 'admin_sidebar_item'));
        add_action('enqueue_block_editor_assets', array($this, 'custom_link_injection_to_gutenberg_toolbar'));

        add_filter('plugin_action_links', array($this, 'settings_hook'), 10, 1);
        add_filter('wp_enqueue_scripts', array($this, 'register_css_and_js'));
        add_filter('post_link', array($this, 'open_external_ad'), 1, 2);
        // add_filter('the_content', array($this, 'add_in_content_nativeAds_to_post_content'));

        add_shortcode('adbirt_ads_display', array($this, 'adbirt_ads_display_shortcode'));
        add_shortcode('adbirt_ad', array($this, 'adbirt_ad_shortcode'));

        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }

    public function add_in_content_nativeAds_to_post_content($content)
    {
        $config = get_option('adbirt_publisher_config', array());
        $config['in_content_native_ads'] = isset($config['in_content_native_ads']) ? $config['in_content_native_ads'] : array();

        $post_id = get_the_ID();
        // $post_type = get_post_type($post_id);

        $campaign_codes = array();

        $should_concatenate = false;

        if (isset($config['in_content_native_ads'][$post_id])) {
            if (count($config['in_content_native_ads'][$post_id]) > 0) {
                // $content .= '<img src="https://www.adbirt.com/public/uploads/campaign_banners/1646836760.gif" />';
                foreach ($config['in_content_native_ads'][$post_id] as $key => $campaign_category) {
                    $campaigns_in_category = array_filter($config['campaigns'], function ($campaign) use ($campaign_category) {
                        if (intval($campaign['campaign']['campaign_category']) == intval($campaign_category)) {
                            return $campaign;
                        }

                        return null;
                    });
                    $campaigns_in_category = array_filter($campaigns_in_category);

                    foreach ($campaigns_in_category as $_index => $single_campaign) {
                        $code = "<a class='ubm-banner' data-id='" . base64_encode($single_campaign["advert_code"]) . "'></a>";
                        array_push($campaign_codes, $code);
                    }
                }
            } else {
                unset($config['in_content_native_ads'][$post_id]);
            }
        } else {
        }

        if (count($campaign_codes) > 0) {
            $should_concatenate = true;
        }

        // if ($should_concatenate) {]
        $paragraphs = explode("</p>", $content);
        $batches = array();

        for ($i = 0; $i <= count($paragraphs); $i++) {
            $paragraph = $paragraphs[$i];
            $paragraph = trim($paragraph);

            if ($i % 10 == 0) {
                if (isset($campaign_codes[$i])) {
                    $snippet = '<br /><hr /> <p>Sponsored</p> <hr />' . $campaign_codes[$i] . '<br /><hr /><br />';
                    $paragraph .= $snippet;

                    array_push($batches, $paragraph);
                }
            } else {
                array_push($batches, $paragraph);
            }
        }

        $content = implode("", $batches);
        // }

        update_option('adbirt_publisher_config', $config);
        return $content;
    }

    public function custom_link_injection_to_gutenberg_toolbar()
    {
        // Here you can also check several conditions,
        // for example if you want to add this link only on CPT  you can
        $screen = get_current_screen();
        // and then
        if ($screen != null) {
            if ('post' === $screen->post_type) {
                wp_enqueue_script('custom-link-in-toolbar', trailingslashit(plugin_dir_url(__FILE__)) . '/assets/js/block-editor.js', array(), '2.0', true);
            }
        }
        // or if you want to add it on all pages
        // wp_enqueue_script('custom-link-in-toolbar', trailingslashit(plugin_dir_url(__FILE__)) . '/assets/js/block-editor.js', array(), '1.0', true);

    }

    public function open_external_ad($url, $post)
    {
        $post = json_decode(wp_json_encode($post), true);

        $config = get_option('adbirt_publisher_config', array());

        try {
            $post_title = $post['post_title'];

            $campaigns = $config['campaigns'];
            $campaigns = array_map(function ($c) {
                return $c['campaign'];
            }, $campaigns);

            foreach ($campaigns as $index => $c) {
                if ($c['campaign_name'] == $post_title) {
                    return  $c['campaign_url'];
                }
            }

            // -
            // $post = get_page_by_title($name, ARRAY_A, 'post');
            // $_post_id = $post['ID'];
            // wp_delete_post($_post_id);
            // -

            // if (in_array($post['ID'], $config['published_native_ads'])) {
            //     return 'http://new-url.com/pagename';
            // } else {
            //     return $url;
            // }
        } catch (\Throwable $th) {
            return $url;
        }

        return $url;

        // return 'https://google.com/search?q=' . urlencode(wp_json_encode($post));
    }

    /**
     * Generates a unique random alpha-numeric string.
     * The string is always unique because it also includes the current unix timestamp 
     * ```php
     * time()
     * ```
     */
    public function generate_random_string($length = 5)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);

        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        return $randomString . '_' . time();
    }

    /**
     * Loads the widget
     */
    public function load_widget()
    {
        return register_widget('AAD_widget');
    }

    public function add_categories_to_site()
    {
        $categories = $this->get_categories();

        file_put_contents('categories.txt', wp_json_encode($categories));

        $config = get_option('adbirt_publisher_config', array());

        $ids = array();

        foreach ($categories as $key => $value) {
            $id = wp_insert_category(array(
                'cat_name' => $value['category_name'],
                'category_description' => $value['category_name']
            ));

            if (($id != false) && ($id != 0)) {
                array_push($ids, $id);
            }
        }

        file_put_contents('ids.txt', wp_json_encode($ids));

        $config['wp_category_ids'] = $ids;

        update_option('wp_category_ids', $ids);

        update_option('adbirt_publisher_config', $config);
    }

    public function remove_categories_from_site()
    {
        $config = get_option('adbirt_publisher_config', array());

        $ids = $config['wp_category_ids'] ?? array();

        foreach ($ids as $key => $id) {
            wp_delete_category($id);
        }

        $config['wp_category_ids'] = null;

        update_option('adbirt_publisher_config', $config);
    }

    public function activate()
    {
        // $this->add_categories_to_site();

        return true;
    }

    public function deactivate()
    {
        // $this->remove_categories_from_site();

        $menu_slug = 'adbirt-publisher';

        /**
         * Removes Adbirt Admin page from wp-admin menu
         */
        remove_menu_page($menu_slug);

        update_option('adbirt_publisher_config', array());
        delete_option('adbirt_publisher_config');

        return true;
    }

    /**
     * This function retrives campaign categories from adbirt.com backend
     */
    public function get_categories()
    {
        $categories = array();

        if (get_transient('adbirt_campaign_categories') == false) {
            // not in cache
            $response = wp_safe_remote_get('https://adbirt.com/campaigns/get-campaign-categories-as-json');
            $body = json_decode($response['body'], true);

            if (intval($body['status']) == 200) {
                $categories = $body['categories'];

                set_transient('adbirt_campaign_categories', $categories, 5 * MINUTE_IN_SECONDS);
            }
        } else {
            // already in cache
            $categories = get_transient('adbirt_campaign_categories');
        }

        return (array)$categories;
    }

    public function getCampaigns(int $user_id)
    {
        return $this->get_campaigns($user_id);
    }

    public function get_campaigns(int $user_id)
    {
        $campaigns = array();

        $response = wp_safe_remote_get('https://adbirt.com/campaigns/get-campaigns-as-json?user_id=' . $user_id);
        $body = json_decode($response['body'], true);

        if (intval($body['status']) == 200) {
            $campaigns = $body['campaigns'];
        }

        return (array)$campaigns;
    }

    public function register_css_and_js()
    {
        $this->register_css();
        $this->register_js();

        return true;
    }

    public function register_css()
    {
        // wp_enqueue_style('ubm-css', 'https://adbirt.com/public/assets/css/ubm.css?ver=2.60', false, '2.5.0', 'all');

        return true;
    }

    public function register_js()
    {
        $url = 'https://adbirt.com/public/assets/js/ubm-jsonp.js?ver=2.70';
        wp_enqueue_script('adbirt-publisher', $url, array('jquery'), '2.6.0', true);

        return true;
    }

    /**
     * Register custom HTTP REST routes for this plugin
     */
    public function register_custom_REST_routes()
    {

        register_rest_route('adbirt/v1', 'ad-in-feed', array(
            'methods' => 'POST',
            'callback' => array($this, 'ad_in_feed_endpoint'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('adbirt/v1', 'set_in-content_native_ad', array(
            'methods' => 'POST',
            'callback' => array($this, 'set_inContent_native_ad_endpoint'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('adbirt/v1', 'get_in-content_native_ad', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_inContent_native_ad_endpoint'),
            'permission_callback' => '__return_true',
        ));
    }

    public function set_inContent_native_ad_endpoint(WP_REST_Request $req)
    {
        $post_id = intval($req->get_param('post_id'));
        $native_ad_category_id = intval($req->get_param('native_ad_category_id'));
        $should_add = strval($req->get_param('is_checked'));

        $config = get_option('adbirt_publisher_config', array());
        $config['in_content_native_ads'] = isset($config['in_content_native_ads']) ? $config['in_content_native_ads'] : array();

        // --

        if (isset($config['in_content_native_ads'][$post_id])) {
            if ($should_add == 'true') {
                // add category to array
                $key = array_search($native_ad_category_id, $config['in_content_native_ads'][$post_id]);
                if ($key === false) {
                    array_push($config['in_content_native_ads'][$post_id], $native_ad_category_id);
                }
            } elseif ($should_add == 'false') {
                // remove category from array
                $key = array_search($native_ad_category_id, $config['in_content_native_ads'][$post_id]);
                if ($key !== false) {
                    unset($config['in_content_native_ads'][$post_id][$key]);
                }
            }
        } else {
            if ($should_add == 'true') {
                $config['in_content_native_ads'][$post_id] = array($native_ad_category_id);
            }
        }

        // --

        update_option('adbirt_publisher_config', $config);
        return rest_ensure_response(array(
            'status' => 200,
            'message' => 'Successfully set in-content native ad',
            'added_or_removed' => $should_add == 'true' ? 'added' : 'removed',
            'in_content_native_ads' => $config['in_content_native_ads'],
            'request_payload' => array(
                'post_id' => $post_id,
                'native_ad_category_id' => $native_ad_category_id,
                'should_add' => $should_add,
            )
        ));
    }

    public function get_inContent_native_ad_endpoint(WP_REST_Request $req)
    {
        return rest_ensure_response(array(
            'status' => 200,
            'message' => 'successful',
            'payload' => $this->get_inContent_native_ad()
        ));
    }

    public function get_inContent_native_ad()
    {
        $config = get_option('adbirt_publisher_config', array());
        $config['in_content_native_ads'] = isset($config['in_content_native_ads']) ? $config['in_content_native_ads'] : array();

        return $config['in_content_native_ads'];
    }


    public function ad_in_feed_endpoint(WP_REST_Request $req)
    {
        try {

            $config = get_option('adbirt_publisher_config', array());
            if (!isset($config['published_native_ads'])) {
                $config['published_native_ads'] = array();
            }

            $params = $req->get_body_params();
            $params['campaign'] = json_decode($params['campaign'], true);

            $campaign = $params['campaign'];
            $id = intval($campaign['id']);
            $name = wp_strip_all_tags($campaign['campaign_name']);
            $text = $campaign['campaign_description'];

            $name .= ' (sponsored)';

            $should_unpublish = false;
            if (isset($params['unpublish']) && $params['unpublish'] == 'true') {
                $should_unpublish = true;
            }

            // should publish to feed

            if (!$should_unpublish) {
                $img_src = 'https://www.adbirt.com/public/uploads/campaign_banners/' . $campaign['campaign_banner'];
                $text = '<img src="' . $img_src . '"> \r\n' . $text;

                //-- begin: set featured image

                // Fetch the binary content of the campaign's banner
                $data = wp_remote_get($img_src);
                // Save the body part to a variable
                $img_bin = $data['body'];
                $img_file_name = array_pop(explode('/', $img_src));
                // $img_file_extension = array_pop(explode('.', $img_file_name));
                $uploaded_image = wp_upload_bits($img_file_name, null, $img_bin);

                if ($uploaded_image['error'] == false) {
                    $img_file_type = wp_check_filetype($img_file_name, null);

                    $response_id = wp_insert_post(array(
                        'post_title' => $name,
                        'post_content' => $text,
                        'post_status' => 'publish',
                        'post_type' => 'post',
                        'post_author' => intval($params['author_id']),
                        'meta_input' => array(
                            'adbirt_ad_campaign_id' => $id,
                        ),
                    ));

                    if ($response_id != false && $response_id != 0) {
                        $config['published_native_ads'][] = intval($id);
                        update_option('adbirt_publisher_config', $config);

                        $attachment = array(
                            'post_mime_type' => $img_file_type['type'],
                            'post_parent'    => $response_id,
                            'post_title'     => preg_replace('/\.[^.]+$/', '', $img_file_name),
                            'post_content'   => '',
                            'post_status'    => 'inherit'
                        );

                        $attachment_id = wp_insert_attachment($attachment, $uploaded_image['file'], $response_id);

                        if (!is_wp_error($attachment_id)) {
                            // if attachment post was successfully created, insert it as a thumbnail to the post $post_id.
                            require_once(ABSPATH . "wp-admin" . '/includes/image.php');

                            $attachment_data = wp_generate_attachment_metadata($attachment_id, $uploaded_image['file']);

                            wp_update_attachment_metadata($attachment_id,  $attachment_data);
                            set_post_thumbnail($response_id, $attachment_id);
                            update_post_meta($response_id, 'attachment_id', $attachment_id);

                            return rest_ensure_response(array(
                                'status' => 200,
                                'message' => 'success',
                                'campaign' => $campaign,
                                'post_id' => $response_id,
                            ));
                        } else {
                            throw new WP_Error(1, 'Error while creating attachment');
                        }
                    } else {
                        throw new WP_Error(1, 'Error publishing ad', array('error' => 'Error publishing ad'));
                    }
                } else {
                    throw new WP_Error(1, 'Error uploading image');
                }

                //-- end: set featured image

            }

            // else, unpublish the ad

            $post = get_page_by_title($name, ARRAY_A, 'post');
            $_post_id = $post['ID'];

            $attachment_id = get_post_meta($_post_id, 'attachment_id', true);

            if ($attachment_id != null && $attachment_id != false && $attachment_id != 0) {
                wp_delete_attachment($attachment_id);
            }

            delete_post_thumbnail($_post_id);
            wp_delete_post($_post_id);

            $_removal_index = array_search(intval($campaign['id']), $config['published_native_ads']);
            unset($config['published_native_ads'][$_removal_index]);

            update_option('adbirt_publisher_config', $config);

            return rest_ensure_response(array(
                'status' => 200,
                'message' => 'unpublished',
                'campaign' => $campaign,
                'post_id' => $_post_id,
            ));
        } catch (\Throwable $th) {
            return rest_ensure_response(array(
                'status' => 500,
                'error' => $th->getMessage()
            ));
        }
    }

    public function settings_hook($links)
    {

        // $this_plugin = false;

        // if (!$this_plugin) {
        //     $this_plugin = plugin_basename(__FILE__);
        // }

        // if (isset($file) && ($file == $this_plugin)) {

        //     $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=adbirt-ads-display">Settings</a>';
        //     array_unshift($links, $settings_link);
        // }

        return $links;
    }

    /**
     * @param {array} attributes = { name: string, id: string, code: string, interval: string }
     * @param {?string} content
     */
    public function adbirt_ad_shortcode($attributes = array(), $content = '')
    {
        $attrs = shortcode_atts(
            array(
                'id' => '',
            ),
            $attributes
        );

        ob_start();
?>
        <a class="ubm-banner" data-id="<?php echo $attrs["id"]; ?>" data-native="recommended"></a>
        <?php
        $markup = ob_get_clean();

        return $markup;
    }

    /**
     * @param {array} attributes = { name: string, id: string, code: string, interval: string }
     * @param {?string} content
     */
    public function adbirt_ads_display_shortcode($attributes = array(), $content = '')
    {
        global $default_config, $default_ad;

        $default_interval = 5;

        $attrs = shortcode_atts(
            array(
                'name' => '',
                'interval' => "$default_interval",
                'category' => '',
            ),
            $attributes
        );

        $config = json_decode(get_option('adbirt_ads_display', json_encode($default_config)), true);
        $ads = $config['ads'] ?? array();
        $name = $attrs['name'];
        $category = isset($attrs['category']) ? $attrs['category'] : '';
        $interval = isset($attrs['interval']) ? intval($attrs['interval']) : $default_interval;

        $markup = '';
        $local_id = 'aad_' . $this->generate_random_string();

        if ($name === '' && is_numeric($interval)) {

            ob_start();
        ?>

            <span id="<?php echo esc_attr($local_id); ?>">
                <style id="<?php echo esc_attr($local_id); ?>_style">
                    span#<?php echo esc_html($local_id); ?>>a {
                        display: none;
                        visibility: hidden;
                    }
                </style>
                <?php foreach ($ads as $ad) {
                    if ($ad['status'] === 'Published') {
                        if ($category !== '') {
                            if (strtolower($ad['category']) === strtolower($category)) {
                                $_local_markup = $ad['code'];
                                echo $_local_markup;
                                // consider ☝️
                            } else {
                                break;
                            }
                        } else {
                            $_local_markup = $ad['code'];
                            echo $_local_markup;
                            // consider ☝️
                        }
                    }
                } ?>
                <script id="<?php echo esc_attr($local_id); ?>_script">
                    (() => {

                        const widths = [];
                        const heights = [];

                        const showAds = async () => {
                            const id = `<?php echo $local_id; ?>`.trim();
                            const ads = <?php echo json_encode($ads) ?>;
                            const interval = <?php echo intval(esc_attr($interval)); ?>;
                            const category = `<?php echo $category; ?>`;

                            let index = 0;
                            while (true) {

                                const selector = `span#<?php echo esc_attr($local_id); ?> > a.ubm_banner`;
                                const ad_elems = Array.from(document.querySelectorAll(selector));

                                if (ad_elems.length === 0) {
                                    await new Promise(resolve => setTimeout(resolve, 0.5 * 1000));
                                    continue;
                                }

                                if ((widths.length < ads.length) && (heights.length < ads.length)) {
                                    ad_elems.forEach(elem => {
                                        widths.push(elem.style.width);
                                        heights.push(elem.style.height);
                                    });
                                }

                                // console.log('showing ad at index: ', index);
                                const ad = ads[index];
                                const ad_elem = ad_elems[index];

                                ad_elems.forEach(elem => {
                                    elem.style.visibility = 'hidden';
                                    elem.style.display = 'none';
                                    elem.style.width = '0px';
                                    elem.style.height = '0px';
                                });

                                ad_elem.style.visibility = 'visible';
                                ad_elem.style.display = 'block';
                                ad_elem.style.width = widths[index];
                                ad_elem.style.height = heights[index];

                                // console.log('current ad element is ', ad_elem);

                                await new Promise(resolve => setTimeout(resolve, interval * 1000));

                                if ((index + 1) == ads.length) {
                                    index = 0;
                                } else {
                                    ++index;
                                }
                            }
                        };

                        setTimeout(() => showAds(), 1000);
                    })();
                </script>
            </span>

            <?php
            $markup = ob_get_clean();
        } else if ($name !== '') {
            $single_ad = array();

            if (sizeof($ads) > 0) {
                foreach ($ads as $ad) {
                    if ($ad['name'] === $name) {
                        $single_ad = $ad;
                        break;
                    }
                }
            } else {
                $single_ad = $default_ad;
            }

            ob_start();
            if (isset($single_ad['status']) && ($single_ad['status'] === 'Published')) {
                echo $single_ad['code'];
            } else {
            ?>
                <!-- Draft: <?php
                            // echo $single_ad['code'];
                            ?> -->
<?php
            }
            $markup = ob_get_clean();
        }

        return $markup;
    }

    public function admin_sidebar_item()
    {
        $page_title = 'Adbirt Publisher Dashboard';
        $menu_slug = 'adbirt-publisher';
        $capability = 'edit_pages';
        $render_function = array($this, 'adbirt_publisher_page_content');
        $icon = 'https://adbirt.com/public/assets-revamp/img/favicon.png';

        add_menu_page($page_title, $page_title, $capability, $menu_slug, $render_function, $icon, 3);
        add_submenu_page($menu_slug, $page_title, $page_title, $capability, $menu_slug, $render_function);
        add_options_page($page_title, $page_title, $capability, $menu_slug, $render_function);

        return true;
    }

    public function getCategoryNameFromId(array $categories, ?string $search)
    {
        require(plugin_dir_path(__FILE__) . 'modules/get-categories-by-id.php');

        __getCategoryNameFromId($categories, $search);
    }

    public static function _getCategoryNameFromId(array $categories, ?string $search)
    {
        require(trailingslashit(plugin_dir_path(__FILE__)) . 'modules/get-categories-by-id.php');

        __getCategoryNameFromId($categories, $search);
    }

    public function adbirt_publisher_page_content()
    {
        require(trailingslashit(plugin_dir_path(__FILE__)) . 'modules/adbirt-publisher-page-content.php');
    }
}
