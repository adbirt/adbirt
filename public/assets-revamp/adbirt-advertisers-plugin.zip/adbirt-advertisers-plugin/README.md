## Adbirt Advertisers wordpress plugin

A wordpress plugin for Adbirt Advertisers. See https://adbirt.com/privacy & https://adbirt.com/terms for TAC/privacy policy.
