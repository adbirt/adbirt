// block-editor.js
// wrapped into IIFE - to leave global space clean.

window.addEventListener('load', () => {
    setTimeout(() => {
        (async (window, wp) => {

            console.log('Working Fine!');

            const generateRandomStringToken = (length = 10) => {
                const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                let token = '';
                for (let i = 0; i < length; i++) {
                    token += possible.charAt(Math.floor(Math.random() * possible.length));
                }
                return token;
            }

            // check if gutenberg's editor root element is present.
            let editorEl = document.getElementById('editor');
            if (!editorEl) { // do nothing if there's no gutenberg root element on page.
                return;
            }

            const postID = Number(document.querySelector('#post_ID').value);
            console.log('The post id is: ', postID);

            const inContentAds_response = await fetch(window.location.href.split('wp-admin')[0] + '/wp-json/adbirt/v1/get_in-content_native_ad?no-cache-token=' + generateRandomStringToken());
            const inContentAds_responseJSON = await inContentAds_response.json();
            const inContentAds_payload = inContentAds_responseJSON['payload'];
            console.log('inContentAds_payload: ', inContentAds_payload);

            /**
             * @type {Record<string, any>[]}
             */
            let categories = [];
            const categoriesRes = await fetch('https://www.adbirt.com/campaigns/get-campaign-categories-as-json?no-cache-token=' + generateRandomStringToken());
            const categoriesJSON = await categoriesRes.json();
            if (Number(categoriesJSON.status) == 200) {
                categories = categoriesJSON.categories;
            }

            console.log('categories: ', categories);

            const _fragment = categories.map(category => {
                return `<label class="adbirt-category-label">
                            <input type="checkbox" value="${category.id}" ${(!Array.isArray(inContentAds_payload) && inContentAds_payload[postID] && Array.isArray(inContentAds_payload[postID]) && inContentAds_payload[postID].includes(Number(category.id))) ? `checked` : `unchecked`} >
                            <span>${category.category_name}</span>
                        </label>
                        <br>`;
            }).join('');

            // just to keep it cleaner - we refer to our link by id for speed of lookup on DOM.
            let link_id = 'adbirt-category-dropdown';

            // prepare our custom link's html.
            let adbirt_categories = `<div class="` + link_id + `" id="` + link_id + `">
            <style>
                .`+ link_id + ` {
                    position: relative;
                    padding: 16px;
                    display: inline-block;
                }
        
                .`+ link_id + `-content {
                    display: none;
                    position: absolute;
                    background-color: #f9f9f9;
                    min-width: 160px;
                    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
                    padding: 12px 16px;
                    z-index: 1;
                    transition: .4s all;
                    height: 250px !important;
                    overflow-y: auto;
                }
        
                .`+ link_id + `:hover .` + link_id + `-content {
                    display: block;
                    height: unset;
                }
        
                .adbirt-category-btn {
                    cursor: pointer;
                }
        
                .adbirt-category-label {
                    padding: 8px;
                    cursor: pointer;
                    display: flex;
                    flex-direction: row;
                    align-items: center;
                    justify-content: flex-start;
                    width: 100%;
                    margin-top: 1px;
                    margin-bottom: 1px;
                }
        
                .adbirt-category-label:hover {
                    background-color: #ddd;
                }
            </style>
        
            <span class="components-button is-primary has-text adbirt-category-btn">Adbirt Ad category</span>
        
            <div class="`+ link_id + `-content">
                ${_fragment}
            </div>
        </div>`;


            /**
             * 
             * @param {InputEvent} e - the event object.
             */
            const onAdbirtCategoryChanged = async (e) => {
                console.log('Clicked');
                const value = e.target.value;
                /**
                 * @type {boolean}
                 */
                const isChecked = e.target.checked;

                console.log('isChecked: ', isChecked);

                try {
                    // A new post is initialized as an 'auto-draft'.
                    // if the post is not a new post it should not save it to avoid some saving conflict between elementor and gutenberg.
                    const isNewPost = 'auto-draft' === wp.data.select('core/editor').getCurrentPost().status;

                    if (isNewPost) {
                        var documentTitle = wp.data.select('core/editor').getEditedPostAttribute('title');
                        if (!documentTitle) {
                            wp.data.dispatch('core/editor').editPost({ title: 'Adbirt #' + postID });
                        }

                        wp.data.dispatch('core/editor').savePost();
                    }

                    const payload = new URLSearchParams({
                        post_id: postID,
                        is_checked: isChecked.toString(),
                        native_ad_category_id: value,
                    });

                    console.log('payload: ', payload);

                    // make api request here
                    const res = await fetch(window.location.href.split('wp-admin')[0] + '/wp-json/adbirt/v1/set_in-content_native_ad?no-cache-token=' + generateRandomStringToken(), {
                        method: 'POST',
                        body: payload
                    });
                    const json = await res.json();
                    console.log(json);
                } catch (error) {
                    console.error(error);
                }
            }

            let unsubscribe = wp.data.subscribe(() => {
                setTimeout(async () => {
                    const categoryDropdown = document.getElementById(link_id);
                    if (!categoryDropdown) {
                        let toolbalEl = editorEl.querySelector('.edit-post-header__toolbar');
                        if (toolbalEl instanceof HTMLElement) {
                            toolbalEl.insertAdjacentHTML('beforeend', adbirt_categories);
                        }
                    } else {
                        /**
                         * @type {HTMLInputElement[]}
                         */
                        const checkBoxes = Array.from(categoryDropdown.querySelectorAll('.adbirt-category-label input'));
                        checkBoxes.forEach((checkbox) => {
                            if (!Boolean(checkbox.oninput)) {
                                checkbox.oninput = onAdbirtCategoryChanged;
                            }
                        });
                    }
                }, 100)
            });
            // unsubscribe is a function - it's not used right now 
            // but in case you'll need to stop this link from being reappeared at any point you can just call unsubscribe();

        })(window, wp);

    }, 1500);
});
